const form = document.getElementById('applicationForm');
form.addEventListener('submit', function (e) {
  const message = document.getElementById('responseMessage');
  message.textContent = "Submitting...";
});
